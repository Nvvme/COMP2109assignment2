<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'RwRl^A.#7T<BW--X#s4vi !*3?oLn>4J8vPOh^^uk2 8G8g1:5#1-@zQHG|?4Ohn' );
define( 'SECURE_AUTH_KEY',   'sU,1VHcM#N4KdQy{^]cdNVcO}S*h Wtv#1+6|,LFqt/z^Cr]RoDd|b2$F~EXQc3a' );
define( 'LOGGED_IN_KEY',     '=5:a 6Kt/[5dTZ-3#ioI@6u,Sj=n^CkqiY%vq5:x`|lv@2A~RxCmi61n~6;K}fDR' );
define( 'NONCE_KEY',         '$S#&hk%_<RpCD}`#(I(nf.ZC2Y I1!y9ntQg5(j!z<tZQ,0FpGEWLBc{h5DyCw6v' );
define( 'AUTH_SALT',         'F[e%18YmvpdFIO-C3V?)(tK5WY#XLeFtd02Yo%+[zl@pS%yw/<=RUsw!%bq&WJcv' );
define( 'SECURE_AUTH_SALT',  'JpofV,6*svs!U+qq5O9toP.!)o/aG.o3Yw|.$n(j>Ui&TK4o(k|[9=0cTXpo~Td$' );
define( 'LOGGED_IN_SALT',    'R4rL1< {6GtNpB.l60+Cn@LqaILvRAIH~+?I8;EQ*,B*UOtHbm)a};9#N1%Q<=FY' );
define( 'NONCE_SALT',        '&exW,z;i8ue+8xKYb0rUe<+am8?cHgzECW4) s(p^bxQA^G^g[l }j >@E0i-@`o' );
define( 'WP_CACHE_KEY_SALT', '#uIu{$T%^3]ttW%37`[(y6;O`mzNqHz0{F zU3h+WqzD+@Aj7h J4=[Gl5`3?#{&' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
